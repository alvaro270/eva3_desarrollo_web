@extends('app')
@section('content')
<div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
            <form class="form-horizontal" method="post">
                @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                @endforeach
                @if(session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif
                {!! csrf_field() !!}
                <fieldset>
                    <legend>Editar Zapatos</legend>
                    <div class="form-group">
                        <label for="calzado" class="col-lg-label">calzado</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="calzado" name="calzado" value="{!!  $zapatos->calzado !!}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="tipo" class="col-lg-label">tipo</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="tipo" name="tipo" value="{!!  $zapatos->tipo !!}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="color" class="col-lg-label">color</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="color" name="color" value="{!!  $zapatos->color !!}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="talla" class="col-lg-label">talla</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="talla" name="talla" value="{!!  $zapatos->talla !!}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="marca" class="col-lg-label">marca</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="marca" name="marca" value="{!!  $zapatos->marca !!}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="genero" class="col-lg-label">genero</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="genero" name="genero" value="{!!  $zapatos->genero !!}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="edades" class="col-lg-label">edades</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="edades" name="edades" value="{!!  $zapatos->edades !!}">
                        </div>
                    </div>
                    
                    <hr>
                    <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <a href="{{route('zapatos.index')}}" class="btn btn-info btn-block" >Atrás</a>
                            <a href="{{route('zapatos.index')}}" type="submit" class="btn btn-success btn-block" >Actualizar</a>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
@stop