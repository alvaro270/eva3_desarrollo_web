@extends('app')
@section('content')
<h1 class="text-primary">Lista de zapatos Adidas</h1>
<table class="table table-bordered" id="tablezapatos">
    <thead>
    <hr>
    <tr>
        <th class="text-center">Id zapato</th>
        <th class="text-center">Calzado</th>
        <th class="text-center">Tipo</th>
        <th class="text-center">Color</th>
        <th class="text-center">Talla</th>
        <th class="text-center">Marca</th>
        <th class="text-center">Genero</th>
        <th class="text-center">Edades</th>
        <th class="text-center">Acciones</th>
        <th class="text-center">Agregar</th>
        <th class="text-center">Editar</th>
        <th class="text-center">Eliminar</th>
    </tr>
    </thead>
    <tbody>
    @foreach($zapatos as $zapato)
        <tr>
            <td class="text-center">{{ $zapato->idzapato}}</td>
            <td class="text-center">{{ $zapato->calzado}}</td>
            <td class="text-center">{{ $zapato->tipo }}</td>
            <td class="text-center">{{ $zapato->color}}</td>
            <td class="text-center">{{ $zapato->talla}}</td>
            <td class="text-center">{{ $zapato->marca}}</td>
            <td class="text-center">{{ $zapato->genero}}</td>
            <td class="text-center">{{ $zapato->edades}}</td>
            <td>
                <a href="{{ route('zapatos.show', $zapato->idzapato) }}" class="btn btn-info">Ver</a>
            </td>
            <td><a class="btn btn-success btn-xs" href="{{ route('zapatos.create') }}">Agregar</a></td>
            <td><a class="btn btn-warning btn-xs" href="{{ action('CbzapatosController@edit', $zapato->idzapato) }}">Editar</a></td>
            <td>
            <form  method="POST" action="{{ url("zapatos/{$zapato->idzapato}") }}">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-xs" type="submit">Eliminar</button>
            </form>
            </td>
        </tr>
    @endforeach
    </tbody>
    <tfoot>
    <tr>
        <th class="text-center">Id zapato</th>
        <th class="text-center">Calzado</th>
        <th class="text-center">Tipo</th>
        <th class="text-center">Color</th>
        <th class="text-center">Talla</th>
        <th class="text-center">Marca</th>
        <th class="text-center">Genero</th>
        <th class="text-center">Edades</th>
        <th class="text-center">Acciones</th>
        <th class="text-center">Agregar</th>
        <th class="text-center">Editar</th>
        <th class="text-center">Eliminar</th>
    </tr>
    </tfoot>
</table>
<hr>
@stop