@extends('app')
@section('content')
<h1>
    Lista de Compra {{ $zapatos->idzapato}}
</h1>

<p>Id moneda; {{ $zapatos->idzapato}}</p>
<p>Calzado: {{ $zapatos->calzado}}</p>
<p>Marca: {{ $zapatos->marca }}</p>
<p>Fecha de Compra: {{ $zapatos->fcompra}}</p>
<p>Tipo de pago:{{ $zapatos->tipopago}}</p>
<p>Monto: {{ $zapatos->monto}}</p>
<hr>

<a href="{{ route('zapatos.index') }}">Volver al índice</a>
<a href="{{ route('zapatos.show', $zapatos->idzapato) }}">Recargar</a>
@stop