@extends('app')
@section('content')
<h1>
    Lista Detallada {{ $venta->idzapato}}
</h1>

<p>Id moneda; {{ $venta->idzapato}}</p>
<p>Calzado: {{ $venta->calzado}}</p>
<p>Marca: {{ $venta->marca }}</p>
<p>Fecha de Compra: {{ $venta->fcompra}}</p>
<p>Tipo de pago:{{ $venta->tipopago}}</p>
<p>Monto: {{ $venta->monto}}</p>
<hr>

<a href="{{ route('venta.index') }}">Volver al índice</a>
<a href="{{ route('venta.show', $venta->idzapato) }}">Recargar</a>
@stop