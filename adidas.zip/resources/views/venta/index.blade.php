@extends('app')
@section('content')
<h1 class="text-primary">Lista de compra</h1>
<table class="table table-bordered" id="tableventa">
    <thead>
    <hr>
    <tr>
        <th class="text-center">Id zapato</th>
        <th class="text-center">Calzado</th>
        <th class="text-center">Marca</th>
        <th class="text-center">Fecha de Compra</th>
        <th class="text-center">Tipo de pago</th>
        <th class="text-center">Monto</th>
        <th class="text-center">Accion</th>
    </tr>
    </thead>
    <tbody>
    @foreach($ventas as $ventas)
        <tr>
            <td class="text-center">{{ $ventas->idzapato}}</td>
            <td class="text-center">{{ $ventas->calzado}}</td>
            <td class="text-center">{{ $ventas->marca }}</td>
            <td class="text-center">{{ $ventas->fcompra}}</td>
            <td class="text-center">{{ $ventas->tipopago}}</td>
            <td class="text-center">{{ $ventas->monto}}</td>
            <td>
                <a href="{{ route('venta.show', $ventas->idzapato) }}" class="btn btn-info">Ver</a>
            </td>
        </tr>
    @endforeach
    </tbody>
    <tfoot>
    <tr>
        <th class="text-center">Id zapato</th>
        <th class="text-center">Calzado</th>
        <th class="text-center">Marca</th>
        <th class="text-center">Fecha de Compra</th>
        <th class="text-center">Tipo de pago</th>
        <th class="text-center">Monto</th>
        <th class="text-center">Accion</th>
    </tr>
    </tfoot>
</table>
<hr>
@stop